---
name: StellarX Submission
about: Submit On Chain Trade Guild for Artisans
title: "On Chain Trade Guild for Artisans"
labels: stellarx, submission
assignees: ""
---

## Project

On Chain Trade Guild for Artisans

## Idea Number

48

## Summary

On Chain Trade Guild for Artisans gives operators a shared settlement score trail, signed wallet actions, and a Soroban-backed release path that can be audited from dashboard to ledger.

## Stellar Usage

- Stellar testnet
- Soroban contract
- Freighter wallet
- Stellar SDK
- XLM/USDC SAC references
